import warnings
warnings.filterwarnings('ignore', category=FutureWarning)
from flask import abort, render_template, Flask
import logging
import db

APP = Flask(__name__)

# Start page
@APP.route('/')
def index():
    stats = {}
    x = db.execute('SELECT COUNT(*) AS jogadores FROM Jogadores').fetchone()
    stats.update(x)
    x = db.execute('SELECT COUNT(*) AS teams FROM Teams').fetchone()
    stats.update(x)
    x = db.execute('SELECT COUNT(*) AS estadios FROM Estadios').fetchone()
    stats.update(x)
    x = db.execute('SELECT COUNT(*) AS jogos FROM Jogos').fetchone()
    stats.update(x)
    x = db.execute('SELECT COUNT(*) AS tecnicos FROM Tecnicos').fetchone()
    stats.update(x)
    return render_template('index.html',stats=stats)

# GET all teams
@APP.route('/teams/')
def list_teams():
    teams = db.execute(
      '''
      SELECT id, nome, n_vitorias, n_derrotas  
      FROM Teams
      ORDER BY id
      ''').fetchall()
    return render_template('teams-list.html', teams=teams)

# GET single team info by id
@APP.route('/teams/<int:id>/')
def get_team(id):

    db.execute("SET @id:=%s;", id)

    team = db.execute(
        '''
        SELECT t.nome, t.idEstadio, t.n_vitorias, t.n_derrotas, t.abreviacao, t.cidade, e.nome as estadio, e.localidade  
        FROM Teams t inner join Estadios e on t.idEstadio = e.id
        WHERE t.id = @id
        ''').fetchone()

    if team is None:
        abort(404, 'Team id {} does not exist.'.format(id))

    coach = db.execute(
        '''
        SELECT nome  
        FROM Tecnicos 
        WHERE id = @id
        ''').fetchone()

    players = db.execute(
        '''
        SELECT nome, id 
        FROM Jogadores
        WHERE idTeam = @id
        ORDER BY nome
        ''').fetchall()

    last_games = db.execute(
        ''' 
            with cte as (
                Select j.id, j.dataHora, j.pontosCasa as pontos, j.pontosVisitante as pontosAgainst, j.idEstadio, t1.nome as team , t2.nome as against, t2.id as idAgainst, e.nome as estadio
                from Jogos j inner join Teams t1 on j.idTeamCasa = t1.id
                inner join Teams t2 on j.idTeamFora = t2.id
                inner join Estadios e on j.idEstadio = e.id
                where t1.id = @id and j.pontosCasa <> 0
            ),
            cte2 as(
                Select j.id, j.dataHora, j.pontosVisitante as pontos, j.pontosCasa as pontosAgainst, j.idEstadio, t1.nome as team, t2.nome as against, t2.id as idAgainst, e.nome as estadio
                from Jogos j inner join Teams t1 on j.idTeamFora = t1.id
                inner join Teams t2 on j.idTeamCasa = t2.id
                inner join Estadios e on j.idEstadio = e.id
                where t1.id = @id and j.pontosVisitante <> 0
            )
            Select id,dataHora, pontos, pontosAgainst, team, against, idEstadio, idAgainst, estadio from cte
            union all
            Select id,dataHora, pontos, pontosAgainst, team, against, idEstadio, idAgainst, estadio  from cte2
            order by dataHora DESC limit 10;

        ''').fetchall()

    next_games = db.execute(
        '''
            with cte as (
                Select j.id, j.dataHora, j.pontosCasa as pontos, j.pontosVisitante as pontosAgainst, j.idEstadio, t1.nome as team , t2.nome as against, t2.id as idAgainst, e.nome as estadio
                from Jogos j inner join Teams t1 on j.idTeamCasa = t1.id
                inner join Teams t2 on j.idTeamFora = t2.id
                inner join Estadios e on j.idEstadio = e.id
                where t1.id = @id and j.pontosCasa = 0
            ),
            cte2 as(
                Select j.id, j.dataHora, j.pontosVisitante as pontos, j.pontosCasa as pontosAgainst, j.idEstadio, t1.nome as team, t2.nome as against, t2.id as idAgainst, e.nome as estadio
                from Jogos j inner join Teams t1 on j.idTeamFora = t1.id
                inner join Teams t2 on j.idTeamCasa = t2.id
                inner join Estadios e on j.idEstadio = e.id
                where t1.id = @id and j.pontosVisitante = 0
            )
            Select id, dataHora, pontos, pontosAgainst, team, against, idEstadio, idAgainst, estadio from cte   
            union all
            Select id, dataHora, pontos, pontosAgainst, team, against, idEstadio, idAgainst, estadio  from cte2
            order by dataHora limit 10;
        ''').fetchall()
    
    return render_template('team.html', team=team, coach=coach, players=players, last_games=last_games, next_games=next_games)

#GET all games by team
@APP.route('/teams/<int:id>/games')
def get_team_all_games(id):
    db.execute("SET @id:=%s;", id)
    games = db.execute(
        ''' 
        with cte as (
            Select j.id, j.dataHora, j.pontosCasa as pontos, j.pontosVisitante as pontosAgainst, j.idEstadio, t1.nome as team , t2.nome as against, t2.id as idAgainst, e.nome as estadio
            from Jogos j inner join Teams t1 on j.idTeamCasa = t1.id
            inner join Teams t2 on j.idTeamFora = t2.id
            inner join Estadios e on j.idEstadio = e.id
            where j.idTeamCasa = @id 
        ),
        cte2 as(
            Select j.id, j.dataHora, j.pontosVisitante as pontos, j.pontosCasa as pontosAgainst, j.idEstadio, t1.nome as team, t2.nome as against, t2.id as idAgainst, e.nome as estadio
            from Jogos j inner join Teams t1 on j.idTeamFora = t1.id
            inner join Teams t2 on j.idTeamCasa = t2.id
            inner join Estadios e on j.idEstadio = e.id
            where j.idTeamFora = @id 
        )
        Select id,dataHora, pontos, pontosAgainst, team, against, idEstadio, idAgainst, estadio from cte 
        union all
        Select id,dataHora, pontos, pontosAgainst, team, against, idEstadio, idAgainst, estadio  from cte2
        order by dataHora;
        ''').fetchall()

    team = db.execute(
        '''
        SELECT t.nome, t.idEstadio, t.n_vitorias, t.n_derrotas, t.abreviacao, t.cidade, e.nome as estadio, e.localidade  
        FROM Teams t inner join Estadios e on t.idEstadio = e.id
        WHERE t.id = @id
        ''').fetchone()

    if team is None:
        abort(404, 'Team id {} does not exist.'.format(id))
    logging.info(games)
    return render_template('team-games.html',games=games, team= team)

#GET teams with input in name
@APP.route('/teams/search/<expr>/')
def search_team(expr):
    search = { 'expr': expr }
    expr = '%' + expr + '%'
    teams = db.execute(
        ''' 
        SELECT id, nome
        FROM Teams 
        WHERE nome LIKE CONCAT('%%', %s, '%%');
        ''', expr).fetchall()
    logging.info(teams)
    return render_template('team-search.html',
            search=search,teams=teams)

# GET all players
@APP.route('/players/')
def list_players():
    players = db.execute(
      '''
        SELECT j.id, j.nome, t.nome as team 
        FROM Jogadores j inner join Teams t on j.idTeam = t.id
        ORDER BY j.id;
      ''').fetchall()
    return render_template('players-list.html', players=players)

# GET single player info by id
@APP.route('/players/<int:id>/')
def get_player(id):
    player = db.execute(
        '''
        SELECT j.nome, j.idade, j.posicao, j.altura, j.peso, j.camisa, j.dataNasc, j.idTeam, t.nome as team  
        FROM Jogadores j inner join Teams t on j.idTeam = t.id
        WHERE j.id = %s
        ''', id).fetchone()

    if player is None:
        abort(404, 'Player id {} does not exist.'.format(id))
    return render_template('player.html', player=player)

#GET players with input in name
@APP.route('/players/search/<expr>/')
def search_player(expr):
    search = { 'expr': expr }
    expr = '%' + expr + '%'
    players = db.execute(
        ''' 
        SELECT id, nome
        FROM Jogadores 
        WHERE nome LIKE CONCAT('%%', %s, '%%');
        ''', expr).fetchall()
    logging.info(players)
    return render_template('player-search.html',
            search=search,players=players)

# GET all coaches
@APP.route('/coaches/')
def list_coaches():
    coaches = db.execute(
      '''
        SELECT tec.id, tec.nome, t.nome as team 
        FROM Tecnicos tec inner join Teams t on tec.idTeam = t.id
        ORDER BY tec.id;
      ''').fetchall()
    return render_template('coaches-list.html', coaches=coaches)

# GET single coach info by id
@APP.route('/coaches/<int:id>/')
def get_coach(id):
    coach = db.execute(
        '''
        SELECT tec.id, tec.nome, tec.dataNasc, tec.tempInicio, tec.anosTime, tec.nacionalidade, tec.idTeam, t.nome as team  
        FROM Tecnicos tec inner join Teams t on tec.idTeam = t.id
        WHERE tec.id = %s
        ''', id).fetchone()

    if coach is None:
        abort(404, 'Coach id {} does not exist.'.format(id))
    return render_template('coach.html', coach=coach)

#GET coaches with input in name
@APP.route('/coaches/search/<expr>/')
def search_coach(expr):
    search = { 'expr': expr }
    expr = '%' + expr + '%'
    coaches = db.execute(
        ''' 
        SELECT id, nome
        FROM Tecnicos 
        WHERE nome LIKE CONCAT('%%', %s, '%%');
        ''', expr).fetchall()
    logging.info(coaches)
    return render_template('coach-search.html',
            search=search,coaches=coaches)

# GET all stadiums
@APP.route('/stadiums/')
def list_stadiums():
    stadiums = db.execute(
      '''
        SELECT s.id, s.nome
        FROM Estadios s
        ORDER BY s.id;
      ''').fetchall()
    return render_template('stadiums-list.html', stadiums=stadiums)

# GET single stadiums info by id
@APP.route('/stadiums/<int:id>/')
def get_stadium(id):
    stadium = db.execute(
        '''
        SELECT s.id, s.nome, s.localidade, t.nome as team , t.id as idTeam 
        FROM Estadios s inner join Teams t on s.id = t.idEstadio
        WHERE s.id = %s
        ''', id).fetchall()

    games_played = db.execute(
        '''
        Select j.id, j.dataHora, j.pontosCasa ,j.pontosVisitante , t1.nome as teamCasa , t2.nome as teamFora, t1.id as idCasa, t2.id as idFora
        from Jogos j inner join Teams t1 on j.idTeamCasa = t1.id
        inner join Teams t2 on j.idTeamFora = t2.id
        where j.idEstadio = %s and j.pontosCasa <> 0
        '''
    ,id).fetchall()

    next_games = db.execute(
        '''
        Select j.id, j.dataHora , t1.nome as teamCasa , t2.nome as teamFora, t1.id as idCasa, t2.id as idFora
        from Jogos j inner join Teams t1 on j.idTeamCasa = t1.id
        inner join Teams t2 on j.idTeamFora = t2.id
        where j.idEstadio = %s and j.pontosCasa = 0
        '''
    ,id).fetchall()

    if stadium is None:
        abort(404, 'Stadium id {} does not exist.'.format(id))
    return render_template('stadium.html', stadium=stadium, games_played=games_played, next_games = next_games)

#GET stadiums with input in name
@APP.route('/stadiums/search/<expr>/')
def search_stadium(expr):
    search = { 'expr': expr }
    expr = '%' + expr + '%'
    stadiums = db.execute(
        ''' 
        SELECT id, nome
        FROM Estadios 
        WHERE nome LIKE CONCAT('%%', %s, '%%');
        ''', expr).fetchall()
    logging.info(stadiums)
    return render_template('stadium-search.html',
            search=search,stadiums=stadiums)

# GET all games
@APP.route('/games/')
def list_games():
    games = db.execute(
      '''
        SELECT j.id, j.dataHora, j.idTeamCasa, j.idTeamFora, t.nome as teamCasa, t2.nome as teamFora 
        FROM Jogos j inner join Teams t on j.idTeamCasa = t.id
        inner join Teams t2 on j.idTeamFora = t2.id
        ORDER BY j.id;
      ''').fetchall()
    return render_template('games-list.html', games=games)

# GET single game info by id
@APP.route('/games/<int:id>/')
def get_game(id):
    game = db.execute(
        '''
        SELECT j.id, DATE_FORMAT(j.dataHora, '%%d/%%m/%%Y %%h:%%i') as dataHora, j.idEstadio, j.pontosCasa, j.pontosVisitante, t.nome as teamCasa, t2.nome as teamFora, e.nome as estadio, e.localidade  
        FROM Jogos j inner join Teams t on j.idTeamCasa = t.id
        inner join Teams t2 on j.idTeamFora = t2.id
        inner join Estadios e on j.idEstadio = e.id
        WHERE j.id = %s
        ''', id).fetchone()

    if game is None:
        abort(404, 'Game id {} does not exist.'.format(id))
    return render_template('game.html', game=game)
